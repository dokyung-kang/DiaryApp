package ddwucom.mobile.finalreport.data

class DiaryDao {
}